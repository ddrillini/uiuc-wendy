local toasty= "Charmy"

local init = cmd(horizalign,left;vertalign,bottom;x,SCREEN_WIDTH;y,SCREEN_HEIGHT)
local on = cmd(decelerate,0.3;x,SCREEN_WIDTH*0.73125;sleep,1.0;accelerate,0.3;x,SCREEN_WIDTH)

local ToastyCommands = {
	charmy = {
		InitCmd = init,
		OnCmd = on
	},
	Charmy= {
		InitCmd = function(self)
			local desired_width= _screen.w * .20
			local desired_height= _screen.h * .4
			local xscale= desired_width / self:GetWidth()
			local yscale= desired_height / self:GetHeight()
			self:zoom(math.min(xscale, yscale))
			self:horizalign(right):vertalign(bottom):xy(_screen.w+desired_width, _screen.h)
		end,
		OnCmd = function(self)
			local original_x= self:GetX()
			self:decelerate(.3):x(_screen.w):sleep(1):accelerate(.3):x(original_x)
		end
	},
	snorlax = {
		InitCmd = cmd(x,SCREEN_CENTER_X;y,SCREEN_TOP-512;zoom,2;draworder,9999),
		OnCmd = cmd(sleep,2.5;linear,1.25;addy,2048)
	}
}

local t = Def.ActorFrame{
	LoadActor( THEME:GetPathG("","_toasty/"..toasty) ) ..{
		StartTransitioningCommand= function(self)
			self:finishtweening()
			ToastyCommands[toasty].InitCmd(self)
			ToastyCommands[toasty].OnCmd(self)
		end
	},
	LoadActor( THEME:GetPathS("_toasty",toasty) ) ..{
		StartTransitioningCommand=cmd(play);
	},
}

return t;
