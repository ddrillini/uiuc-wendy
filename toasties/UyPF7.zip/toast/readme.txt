This is just a package of the toasty stuff that Cube posted on the SMO forums.
It uses the theme fallback system to fallback on the default theme, adding the toasties he posted.
If default isn't your preferred theme, change the FallbackTheme metric in metrics.ini and it will probably work.

